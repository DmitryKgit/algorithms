var ninja = "Yoshi";
var message = "Hello";

function sayHiToNinja() {
  return message + " " + ninja;
}
export { message, sayHiToNinja }; 