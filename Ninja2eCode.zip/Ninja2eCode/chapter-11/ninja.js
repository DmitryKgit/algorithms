var ninja = "Yoshi";
export var message = "Hello";

export function sayHiToNinja() {
  return message + " " + ninja;
}
